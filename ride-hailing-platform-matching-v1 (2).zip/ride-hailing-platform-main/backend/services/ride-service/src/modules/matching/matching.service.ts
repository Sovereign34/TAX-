import {
  ConflictException,
  ForbiddenException,
  Inject,
  Injectable,
  Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import Redis from 'ioredis';
import {
  NearbyDriversDto,
  RIDE_CONSTANTS,
  calculateETA,
  haversineDistanceMeters,
} from '@ride/shared';
import { RideEntity, RideStatus } from '../rides/entities/ride.entity';
import { TrackingGateway } from '../tracking/tracking.gateway';
import { REDIS_CLIENT } from '../../redis/redis.module';

export interface NearbyDriver {
  driverId: string;
  userId: string;
  firstName: string;
  vehicleType: string;
  vehicleNumber: string;
  vehicleModel: string;
  vehicleColor?: string;
  latitude: number;
  longitude: number;
  distanceMeters: number;
  etaSeconds: number;
  rating: number;
}

// Redis key contract (location-service writes GEO/LOC/META, matching writes the rest)
const GEO_KEY = 'driver:locations';
const LOC_PREFIX = 'driver:loc:'; // JSON {updatedAt,...}
const META_PREFIX = 'driver:meta:'; // hash: userId, firstName, vehicleType, ...
const BUSY_PREFIX = 'driver:busy:'; // value = rideId
const OFFER_PREFIX = 'driver:offer:'; // value = rideId, TTL = response timeout
const assignedKey = (rideId: string) => `ride:${rideId}:assigned`;
const declinedKey = (rideId: string, driverId: string) =>
  `ride:${rideId}:declined:${driverId}`;

const STALE_LOCATION_MS = 30_000;
const POLL_MS = 500;
const RETRY_WHEN_EMPTY_MS = 3_000;

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

@Injectable()
export class MatchingService {
  private readonly logger = new Logger(MatchingService.name);

  constructor(
    @Inject(REDIS_CLIENT) private readonly redis: Redis,
    @InjectRepository(RideEntity) private readonly rideRepo: Repository<RideEntity>,
    private readonly tracking: TrackingGateway,
  ) {}

  /** Entry point called after a ride is booked. Runs until assigned, cancelled or timed out. */
  async findNearbyDrivers(ride: RideEntity): Promise<void> {
    const started = Date.now();
    const deadline = started + RIDE_CONSTANTS.SEARCH_TIMEOUT_SECONDS * 1000;
    const tried = new Set<string>();

    while (Date.now() < deadline) {
      if (await this.isClosed(ride.id)) return;

      const widen = Date.now() - started > (deadline - started) / 2;
      const candidates = (
        await this.searchNearbyDrivers({
          latitude: Number(ride.pickupLatitude),
          longitude: Number(ride.pickupLongitude),
          rideType: ride.rideType as any,
          radiusKm: widen ? RIDE_CONSTANTS.MAX_SEARCH_RADIUS_KM : RIDE_CONSTANTS.SEARCH_RADIUS_KM,
          limit: 10,
        })
      ).filter((d) => !tried.has(d.driverId));

      if (candidates.length === 0) {
        await sleep(RETRY_WHEN_EMPTY_MS);
        continue;
      }

      const driver = candidates[0];
      tried.add(driver.driverId);
      if (await this.offerToDriver(ride, driver)) return;
    }

    await this.markNoDriver(ride);
  }

  async searchNearbyDrivers(dto: NearbyDriversDto): Promise<NearbyDriver[]> {
    const radiusKm = dto.radiusKm ?? RIDE_CONSTANTS.SEARCH_RADIUS_KM;
    const limit = dto.limit ?? 10;

    // [member, distKm, [lng, lat]]
    const raw = (await this.redis.georadius(
      GEO_KEY, dto.longitude, dto.latitude, radiusKm, 'km',
      'WITHCOORD', 'WITHDIST', 'ASC', 'COUNT', limit * 3,
    )) as Array<[string, string, [string, string]]>;

    const now = Date.now();
    const enriched = await Promise.all(
      raw.map(async ([driverId, , [lng, lat]]) => {
        const [loc, meta, busy] = await Promise.all([
          this.redis.get(LOC_PREFIX + driverId),
          this.redis.hgetall(META_PREFIX + driverId),
          this.redis.exists(BUSY_PREFIX + driverId),
        ]);
        if (!loc || busy || !meta || !meta.vehicleType) return null;
        if (now - new Date(JSON.parse(loc).updatedAt).getTime() > STALE_LOCATION_MS) return null;
        if (dto.rideType && meta.vehicleType !== dto.rideType) return null;

        const latitude = parseFloat(lat);
        const longitude = parseFloat(lng);
        const distance = haversineDistanceMeters(dto.latitude, dto.longitude, latitude, longitude);
        const driver: NearbyDriver = {
          driverId,
          userId: meta.userId || driverId,
          firstName: meta.firstName || '',
          vehicleType: meta.vehicleType,
          vehicleNumber: meta.vehicleNumber || '',
          vehicleModel: meta.vehicleModel || '',
          vehicleColor: meta.vehicleColor,
          latitude,
          longitude,
          distanceMeters: Math.round(distance),
          etaSeconds: calculateETA(distance),
          rating: Number(meta.rating) || 0,
        };
        return driver;
      }),
    );

    return enriched
      .filter((d): d is NearbyDriver => d !== null)
      .sort((a, b) => a.distanceMeters - b.distanceMeters)
      .slice(0, limit);
  }

  /** Reserve driver (SET NX) -> push offer -> wait for accept/decline/timeout. */
  private async offerToDriver(ride: RideEntity, driver: NearbyDriver): Promise<boolean> {
    const timeout = RIDE_CONSTANTS.DRIVER_RESPONSE_TIMEOUT_SECONDS;
    const reserved = await this.redis.set(OFFER_PREFIX + driver.driverId, ride.id, 'EX', timeout, 'NX');
    if (!reserved) return false; // driver already holds another offer

    this.tracking.sendRideOffer(driver.userId, {
      rideId: ride.id,
      driverId: driver.driverId,
      pickupAddress: ride.pickupAddress,
      pickupLatitude: Number(ride.pickupLatitude),
      pickupLongitude: Number(ride.pickupLongitude),
      dropoffAddress: ride.dropoffAddress,
      estimatedFare: Number(ride.estimatedFare),
      distanceToPickupMeters: driver.distanceMeters,
      etaSeconds: driver.etaSeconds,
      expiresInSeconds: timeout,
    });

    const end = Date.now() + timeout * 1000;
    let tick = 0;
    while (Date.now() < end) {
      if ((await this.redis.get(assignedKey(ride.id))) === driver.driverId) return true;
      if (await this.redis.get(declinedKey(ride.id, driver.driverId))) break;
      if (++tick % 4 === 0 && (await this.isClosed(ride.id))) break;
      await sleep(POLL_MS);
    }

    await this.redis.del(OFFER_PREFIX + driver.driverId);
    return (await this.redis.get(assignedKey(ride.id))) === driver.driverId;
  }

  /** Called by the driver. Atomic: only one driver can ever claim a ride. */
  async acceptRide(rideId: string, driverId: string, requesterUserId: string): Promise<RideEntity> {
    const meta = await this.redis.hgetall(META_PREFIX + driverId);
    if (!meta?.userId || meta.userId !== requesterUserId) {
      throw new ForbiddenException('Not allowed to act as this driver');
    }
    if ((await this.redis.get(OFFER_PREFIX + driverId)) !== rideId) {
      throw new ConflictException('Offer expired or not addressed to this driver');
    }

    const claimed = await this.redis.set(assignedKey(rideId), driverId, 'EX', 6 * 3600, 'NX');
    if (!claimed) throw new ConflictException('Ride already assigned');

    const result = await this.rideRepo.update(
      { id: rideId, status: RideStatus.SEARCHING },
      { driverId, status: RideStatus.DRIVER_ASSIGNED },
    );
    if (!result.affected) {
      await this.redis.del(assignedKey(rideId)); // ride was cancelled meanwhile
      throw new ConflictException('Ride is no longer available');
    }

    await this.redis.set(BUSY_PREFIX + driverId, rideId, 'EX', 4 * 3600);
    await this.redis.del(OFFER_PREFIX + driverId);

    const ride = await this.rideRepo.findOneOrFail({ where: { id: rideId } });
    this.tracking.broadcastRideUpdate(ride);
    return ride;
  }

  async declineRide(rideId: string, driverId: string, requesterUserId: string): Promise<void> {
    const meta = await this.redis.hgetall(META_PREFIX + driverId);
    if (!meta?.userId || meta.userId !== requesterUserId) {
      throw new ForbiddenException('Not allowed to act as this driver');
    }
    await this.redis.set(declinedKey(rideId, driverId), '1', 'EX', 60);
  }

  /** Free the driver once a ride ends/cancels (call from ride status updates). */
  async releaseDriver(driverId: string): Promise<void> {
    await this.redis.del(BUSY_PREFIX + driverId);
  }

  private async isClosed(rideId: string): Promise<boolean> {
    const ride = await this.rideRepo.findOne({ where: { id: rideId }, select: ['id', 'status'] });
    return !ride || ride.status !== RideStatus.SEARCHING;
  }

  private async markNoDriver(ride: RideEntity): Promise<void> {
    const res = await this.rideRepo.update(
      { id: ride.id, status: RideStatus.SEARCHING },
      {
        status: RideStatus.CANCELLED,
        cancelledAt: new Date(),
        cancelledBy: 'system',
        cancellationReason: 'no_drivers_available',
      },
    );
    if (res.affected) {
      this.logger.warn(`No driver accepted ride ${ride.id}`);
      const updated = await this.rideRepo.findOne({ where: { id: ride.id } });
      if (updated) this.tracking.broadcastRideUpdate(updated);
    }
  }
}
