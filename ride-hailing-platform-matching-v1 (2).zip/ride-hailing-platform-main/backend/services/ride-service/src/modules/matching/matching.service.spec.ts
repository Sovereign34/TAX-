import { ConflictException, ForbiddenException } from '@nestjs/common';
import { MatchingService } from './matching.service';
import { RideStatus } from '../rides/entities/ride.entity';

const fresh = () => JSON.stringify({ updatedAt: new Date().toISOString() });
const stale = () => JSON.stringify({ updatedAt: new Date(Date.now() - 120_000).toISOString() });

function makeService(store: Record<string, any> = {}) {
  const redis: any = {
    georadius: jest.fn(),
    get: jest.fn(async (k: string) => store[k] ?? null),
    exists: jest.fn(async (k: string) => (store[k] ? 1 : 0)),
    hgetall: jest.fn(async (k: string) => store[k] ?? {}),
    set: jest.fn(async (k: string, v: any, ...args: any[]) => {
      if (args.includes('NX') && store[k] !== undefined) return null;
      store[k] = v;
      return 'OK';
    }),
    del: jest.fn(async (k: string) => { delete store[k]; return 1; }),
  };
  const rideRepo: any = {
    update: jest.fn().mockResolvedValue({ affected: 1 }),
    findOne: jest.fn(),
    findOneOrFail: jest.fn().mockResolvedValue({ id: 'r1', status: RideStatus.DRIVER_ASSIGNED }),
  };
  const tracking: any = { sendRideOffer: jest.fn(), broadcastRideUpdate: jest.fn() };
  return { svc: new MatchingService(redis, rideRepo, tracking), redis, rideRepo, tracking, store };
}

describe('MatchingService.searchNearbyDrivers', () => {
  it('returns only fresh, free, type-matching drivers sorted by distance', async () => {
    const store: any = {
      'driver:loc:a': fresh(), 'driver:meta:a': { vehicleType: 'cab', userId: 'ua' },
      'driver:loc:b': fresh(), 'driver:meta:b': { vehicleType: 'cab', userId: 'ub' },
      'driver:loc:c': stale(), 'driver:meta:c': { vehicleType: 'cab', userId: 'uc' }, // stale
      'driver:loc:d': fresh(), 'driver:meta:d': { vehicleType: 'bike', userId: 'ud' }, // wrong type
      'driver:loc:e': fresh(), 'driver:meta:e': { vehicleType: 'cab', userId: 'ue' }, 'driver:busy:e': 'x', // busy
    };
    const { svc, redis } = makeService(store);
    redis.georadius.mockResolvedValue([
      ['b', '2.0', ['28.9900', '41.0100']],
      ['a', '1.0', ['28.9800', '41.0000']],
      ['c', '1.5', ['28.9800', '41.0000']],
      ['d', '1.6', ['28.9800', '41.0000']],
      ['e', '1.7', ['28.9800', '41.0000']],
    ]);
    const res = await svc.searchNearbyDrivers({ latitude: 41.0, longitude: 28.98, rideType: 'cab' as any });
    expect(res.map((d) => d.driverId)).toEqual(['a', 'b']);
  });
});

describe('MatchingService.acceptRide', () => {
  const base = () => ({
    'driver:meta:d1': { userId: 'u1' },
    'driver:offer:d1': 'r1',
  });

  it('rejects when caller is not the driver', async () => {
    const { svc } = makeService(base());
    await expect(svc.acceptRide('r1', 'd1', 'someone-else')).rejects.toBeInstanceOf(ForbiddenException);
  });

  it('rejects when there is no live offer for this ride', async () => {
    const { svc } = makeService({ 'driver:meta:d1': { userId: 'u1' } });
    await expect(svc.acceptRide('r1', 'd1', 'u1')).rejects.toBeInstanceOf(ConflictException);
  });

  it('only one driver can claim a ride', async () => {
    const store: any = {
      ...base(),
      'driver:meta:d2': { userId: 'u2' },
      'driver:offer:d2': 'r1',
    };
    const { svc } = makeService(store);
    await svc.acceptRide('r1', 'd1', 'u1');
    await expect(svc.acceptRide('r1', 'd2', 'u2')).rejects.toBeInstanceOf(ConflictException);
    expect(store['ride:r1:assigned']).toBe('d1');
    expect(store['driver:busy:d1']).toBe('r1');
  });

  it('rolls back the claim if the ride was cancelled meanwhile', async () => {
    const { svc, rideRepo, store } = makeService(base());
    rideRepo.update.mockResolvedValue({ affected: 0 });
    await expect(svc.acceptRide('r1', 'd1', 'u1')).rejects.toBeInstanceOf(ConflictException);
    expect(store['ride:r1:assigned']).toBeUndefined();
  });
});
