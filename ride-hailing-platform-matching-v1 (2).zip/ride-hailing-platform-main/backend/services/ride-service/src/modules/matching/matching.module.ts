import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MatchingService } from './matching.service';
import { RideEntity } from '../rides/entities/ride.entity';
import { TrackingModule } from '../tracking/tracking.module';

@Module({
  imports: [TypeOrmModule.forFeature([RideEntity]), TrackingModule],
  providers: [MatchingService],
  exports: [MatchingService],
})
export class MatchingModule {}
